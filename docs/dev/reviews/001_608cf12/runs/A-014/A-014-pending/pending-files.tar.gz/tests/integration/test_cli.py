"""Verify the public module CLI through real named-file subprocesses."""

import contextlib
import errno
import io
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from textstats.cli import main

PROJECT_ROOT = Path(__file__).resolve().parents[2]


class CliProcessChecks:
    """Share real module subprocess checks without duplicating test collection."""

    def run_cli(self, path, *options, cwd=PROJECT_ROOT):
        """Launch the actual module while keeping verification bytecode-free."""
        return self.run_command([*options, str(path)], cwd=cwd)

    def run_command(self, arguments, *, cwd=PROJECT_ROOT, preexec_fn=None):
        """Launch arbitrary CLI arguments for usage and OS failure checks."""
        environment = os.environ.copy()
        environment["PYTHONDONTWRITEBYTECODE"] = "1"
        environment["PYTHONPATH"] = str(PROJECT_ROOT)
        return subprocess.run(
            [sys.executable, "-m", "textstats", *arguments],
            cwd=cwd, env=environment, capture_output=True, text=True,
            encoding="utf-8", timeout=10, check=False, preexec_fn=preexec_fn,
        )

    def assert_success(self, result, expected_stdout):
        """Check all observable success channels with literal output."""
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout, expected_stdout)
        self.assertEqual(result.stderr, "")

class NamedFileCliTests(CliProcessChecks, unittest.TestCase):
    """Protect exact success output, BOM modes and unchanged named inputs."""

    def test_named_file_success_boundaries(self):
        cases = [
            ("", "lines=0 words=0\n"),
            ("alpha beta", "lines=1 words=2\n"),
            ("alpha\r\nbeta\rgamma\n", "lines=3 words=3\n"),
            ("café\u00a0猫\u2028dog\n", "lines=1 words=3\n"),
            ("alpha\n\n", "lines=2 words=1\n"),
            (" \t", "lines=1 words=0\n"),
        ]
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "sample.txt"
            for text, output in cases:
                with self.subTest(text=text):
                    path.write_bytes(text.encode("utf-8"))
                    self.assert_success(self.run_cli(path), output)

    def test_keep_bom_composes_with_named_input(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "bom.txt"
            path.write_bytes("\ufeff alpha\r\nbeta\n".encode("utf-8"))
            self.assert_success(self.run_cli(path), "lines=2 words=2\n")
            self.assert_success(self.run_cli(path, "--keep-bom"), "lines=2 words=3\n")

    def test_bom_only_and_interior_bom(self):
        cases = [
            ("\ufeff", (), "lines=0 words=0\n"),
            ("\ufeff", ("--keep-bom",), "lines=1 words=1\n"),
            ("alpha \ufeff beta", (), "lines=1 words=3\n"),
        ]
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "bom.txt"
            for text, options, output in cases:
                with self.subTest(text=text, options=options):
                    path.write_bytes(text.encode("utf-8"))
                    self.assert_success(self.run_cli(path, *options), output)

    def test_named_input_with_spaces_is_not_modified(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "file with spaces.txt"
            data = b"alpha beta\n"
            path.write_bytes(data)
            self.assert_success(self.run_cli(path), "lines=1 words=2\n")
            self.assertEqual(path.read_bytes(), data)

    def test_dash_is_a_named_file_before_stdin_delivery(self):
        with tempfile.TemporaryDirectory() as directory:
            (Path(directory) / "-").write_bytes(b"named input\n")
            self.assert_success(self.run_cli("-", cwd=directory), "lines=1 words=2\n")


class BaselineFailureCliTests(CliProcessChecks, unittest.TestCase):
    """Check error/usage channels and actual filesystem permission denial."""

    def assert_read_failure(self, result, input_name, cause):
        """Require a useful named diagnostic without success output/traceback."""
        self.assertEqual(result.returncode, 1)
        self.assertEqual(result.stdout, "")
        self.assertIn(str(input_name), result.stderr)
        self.assertIn(cause, result.stderr.lower())
        self.assertNotIn("Traceback", result.stderr)

    def test_missing_malformed_and_directory_inputs(self):
        with tempfile.TemporaryDirectory() as directory:
            missing = Path(directory) / "missing.txt"
            invalid = Path(directory) / "invalid.txt"
            invalid.write_bytes(b"alpha\n\xff")
            for path, cause in [(missing, "no such file"), (invalid, "utf-8"),
                                (Path(directory), "directory")]:
                with self.subTest(path=path):
                    self.assert_read_failure(self.run_cli(path), path, cause)

    def test_invalid_invocations_use_usage_status_and_channels(self):
        for arguments in ([], ["first", "second"], ["--unknown", "file"], ["--keep-bom"]):
            with self.subTest(arguments=arguments):
                result = self.run_command(arguments)
                self.assertEqual(result.returncode, 2)
                self.assertEqual(result.stdout, "")
                self.assertTrue(result.stderr.strip())
                self.assertNotIn("Traceback", result.stderr)

    def test_help_succeeds_without_stderr(self):
        result = self.run_command(["--help"])
        self.assertEqual(result.returncode, 0)
        self.assertTrue(result.stdout.strip())
        self.assertIn("--keep-bom", result.stdout)
        self.assertEqual(result.stderr, "")

    def test_double_dash_supports_dash_prefixed_filename(self):
        with tempfile.TemporaryDirectory() as directory:
            (Path(directory) / "-sample.txt").write_bytes(b"alpha beta\n")
            self.assert_success(self.run_command(["--", "-sample.txt"], cwd=directory),
                                "lines=1 words=2\n")

    def test_permission_denial_at_real_file_open_boundary(self):
        # This privileged runner cannot change its child's UID/GID. A controlled
        # EACCES at open supplements the real missing/malformed file subprocesses.
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "denied.txt"
            path.write_bytes(b"alpha beta\n")
            denied = PermissionError(errno.EACCES, os.strerror(errno.EACCES), str(path))
            stdout, stderr = io.StringIO(), io.StringIO()
            with patch("textstats.files.open", side_effect=denied, create=True):
                with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
                    status = main([str(path)])
            self.assertEqual(status, 1)
            self.assertEqual(stdout.getvalue(), "")
            self.assertIn(str(path), stderr.getvalue())
            self.assertIn("permission denied", stderr.getvalue().lower())
            self.assertNotIn("Traceback", stderr.getvalue())
            self.assertEqual(path.read_bytes(), b"alpha beta\n")
